#if (ARDUINO >=100)
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif
#include "constants.h"


#ifndef IDEAMART_H
#define IDEAMART_H
//class IdeaMart {
//  public:
  
  //constructor
  //IdeaMart(bool displayMsg=false);

  //methods
  void bootInit();
  void setupGSM();
  void smsReport(String state);
  void verifyGPRSCon();
  //bool timeout(const int DELAY, long *previousMillis, bool *flag);
  //bool makeCon(void (*f)());
  bool mqttCon();
  void setupMQTT();
  void cb(char* t, byte* payload, unsigned int l) ;
  void sendEvent();
  void doA(const char* message,String id);
  void fota();
  void health(String id);
  int responsef(uint8_t *buffer, int len);
  int wdataf(uint8_t *buffer, int len);
  void progressf(int percent);
  void calibGrove();
//  private:
//};

void IRAM_ATTR onTimer();

#endif
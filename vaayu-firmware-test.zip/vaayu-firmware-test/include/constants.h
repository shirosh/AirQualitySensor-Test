
#define TINY_GSM_MODEM_SIM7000 // define modem type

#define FIRMWARE_VER    "Vaayu_V1_Test"
#define MCU             "ESP32_WROOM_Dev_Module"

#define MQTT_MAX_PACKET_SIZE    512

#define SEALEVELPRESSURE_HPA (1013.25)
#define TIME_INTERVAL   10

//5 seconds scalar
#define TIME_SCALAR     50000

#define RST_COUNTER     1440

#define IMEI_SIZE       15
#define CCID_SIZE       16

#define SERIAL_RATE     115200

//Flash Constatnts
#define RST_ADDR        0
#define INTERVAL_ADDR   10
#define APN_ADDR        20
#define NM_ADDR         30
#define PM_ADDR         40
#define SSID_ADDR       60
#define PASS_ADDR       80
#define EEPROM_SIZE     512


#define ESP_RST         32

//GSM pin configuration
#define GSM_PWR         12
#define GSM_RX          15
#define GSM_TX          14
#define GSM_RST         13
#define MODEM_RATE      9600

#define TIMEOUT_DELAY   5000


//Sensor pin configuration
#define SENSOR_RX       16
#define SENSOR_TX       17
#define SENSOR_RATE     115200
#define TX_ENABLE       5

//ideamart IoT parameters
#define NET_APN         "dialogbb "
#define APN_USER        ""
#define APN_PASS        ""
#define HTTP_SERVER     ""
#define HTTP_RESOURCE   ""
#define HTTP_PORT       8080
#define DEVICE_ID       ""

//ideamart mqtt parameters
#define MQTT_BROKER     "mqtt.iot.ideamart.io"
#define MQTT_PORT       1883
#define ACTION_TOPIC    ""
#define RES_TOPIC       ""
#define EVENT_TOPIC     ""
#define MQTT_USER       ""
#define MQTT_PASS       ""

#define INPUT_RES       "\"status\":\"ok\""

//Grove Multichannel Gas Sensor Calibration
// Note that it need 10 minutes pre-heat before calibration
#define SENSOR_ADDR     0X04        // default to 0x04
#define PRE_HEAT_TIME   0           // pre-heat time, 10-30 minutes is recommended

//I2C PINS
//SCL   22 
//SDA   21


#define WIFI_SSID "ideamart"
#define WIFI_PASS "dialog"


#define VERSION 1

#define PIN        25
#define NUMPIXELS 16

#define BME_ADDR 0x76
//#define BME_ADDR 0x77
#define GAS_AADR 0x04
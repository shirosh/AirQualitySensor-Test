#include "constants.h"
#include <TinyGsmClient.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <EEPROM.h>
#include <HTTPClient.h>
#include <PMserial.h>
#include "IdeaMart.h"
#include "MICS-VZ-89TE.h"
#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>
#include "MutichannelGasSensor.h"
#include <WiFi.h>
#include "SPIFFS.h"
#include "Update.h"
#include "time.h"
//#include <Adafruit_NeoPixel.h>

// Hardware serial objects
HardwareSerial SerialGSM(1);
HardwareSerial SerialSensor(2);

// create GSM object
TinyGsm modemGSM(SerialGSM);
TinyGsmClient client(modemGSM);

//HttpClient http(client, HTTP_SERVER, HTTP_PORT);

PubSubClient ideamartmqtt(client);

/* const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 19800;
const int   daylightOffset_sec = 0; */



SerialPM pms(PMSx003, Serial2); 
MICS_VZ_89TE mics;

unsigned int rst_cnt,modemFails, gprsFails, gsmFails,mqttFails,nm,pm;

String ccid,imei,cop;
int    sig, bat,dataSendCount;

/* create a hardware timer */
hw_timer_t * timer = NULL;
unsigned long dataInterval;
bool readyToSend=false;


//Adafruit_NeoPixel pixels(1, PIN, NEO_GRB + NEO_KHZ800);

char msg[200];
unsigned int sequenceNo=0;
char actionTopic[100]="+/";
char actionResTopic[100]="/";


String apnName,wifiSSID,wifiPass;
//char wifiSSID,wifiPass;

Adafruit_BME280 bme;


void bootInit(){


  digitalWrite(ESP_RST,HIGH);
  Serial.begin(SERIAL_RATE);
  Serial.println("Booting... This is Hardware Test.");
  pinMode(GSM_PWR,OUTPUT);




  EEPROM.begin(EEPROM_SIZE);
  rst_cnt = EEPROM.readUInt(RST_ADDR);
  
  rst_cnt= rst_cnt + 1; 
  
    apnName="dialogbb";
    dataInterval=2*TIME_SCALAR;
    EEPROM.writeULong(INTERVAL_ADDR, dataInterval);
    EEPROM.commit();
    EEPROM.writeString(APN_ADDR, apnName);
    EEPROM.commit();
    EEPROM.writeUInt(NM_ADDR,13);
    EEPROM.commit();
    EEPROM.writeUInt(PM_ADDR,3);
    EEPROM.commit();
    EEPROM.writeString(SSID_ADDR,"IDEAMART-IOT");
    EEPROM.commit();
    EEPROM.writeString(PASS_ADDR,"B=G9$_X_LKRdb!Gs");
    EEPROM.commit();

  
  //EEPROM.writeUInt(RST_ADDR, 0);
  EEPROM.writeUInt(RST_ADDR, rst_cnt);
  if(EEPROM.commit()==true){
    Serial.println("EEEPROM: OK");
  }
  
  
  
  /* WiFi.mode(WIFI_STA);
  WiFi.begin(wifiSSID, wifiPass);
  while (WiFi.waitForConnectResult() != WL_CONNECTED) {
    Serial.println("Connection Failed! Rebooting...");
    delay(5000);
    
  } */
  
  pms.init();
  mics.begin();
  

  //pixels.begin();
  //pixels.clear();
}

void setupGSM()
{
  Serial.println("Network Setup------>");
  digitalWrite(GSM_PWR,HIGH);
  delay(200);

   // Initiate serial SIM7000
  SerialGSM.begin(MODEM_RATE, SERIAL_8N1, GSM_RX, GSM_TX, false);

  delay(8000); 

  Serial.println("Modem Info------>");
  imei=modemGSM.getIMEI();
  ccid=modemGSM.getSimCCID();

  
  
  // print Modem model
  Serial.println(modemGSM.getModemInfo());
  Serial.println(imei);
  Serial.println(modemGSM.getSignalQuality());

  
  
  Serial.println(ccid);
  
    Serial.println(modemGSM.setNetworkMode(nm));             // 38-LTE 13-gsm 2-Auto 51-LTE&GSM
    Serial.println(modemGSM.setPreferredMode(pm)); 
 
  
  if (!modemGSM.waitForNetwork()) 
  {
    //gsmFails++;
    Serial.println("Network: Failed");
    
    delay(5000);
    //ESP.restart();
    return;
  }
  Serial.println("Network: OK");
  
  // conecta na rede (tecnologia GPRS)
  if(!modemGSM.gprsConnect(NET_APN,APN_USER,APN_PASS))
  {
    gprsFails++;
    Serial.println("GPRS: Failed");
    
    delay(5000);
    //ESP.restart();
    return;
  }
   
  Serial.println("GPRS: OK");



}


void sendEvent(){
  Serial.print("Sequence No: ");Serial.println(sequenceNo);
  pms.read();
  bme.begin(BME_ADDR);
  gas.begin(GAS_AADR);//the default I2C address of the slave is 0x04
  gas.powerOn();
  mics.readSensor();
  
  StaticJsonDocument<600> doc;
  JsonObject root = doc.to<JsonObject>();

    
    root["temp"] = bme.readTemperature(); //temperature(C)
    root["pres"] = bme.readPressure();  //pressure(Pa)
    root["alti"] = bme.readAltitude(SEALEVELPRESSURE_HPA);  //altitude (sea level pressure hPa)
    root["humi"] = bme.readHumidity();;  //humidity (%)
    root["NH3"] = gas.measure_NH3();  //ammonia(ppm)
    root["CO"] = gas.measure_CO();  //carbon monoxide(ppm)
    root["NO2"] = gas.measure_NO2();  //nitrogen dioxide(ppm)
    root["C3H8"] = gas.measure_C3H8();  //propane(ppm)
    root["C4h10"] = gas.measure_C4H10();   //butane(ppm)
    root["CH4"] = gas.measure_CH4();  //methane(ppm)
    root["H2"] = gas.measure_H2();  //hydrogen(ppm)
    root["C2H5OH"] = gas.measure_C2H5OH();  //ethanol(ppm)
    root["CO2"] = mics.getCO2();  //carbon dioxide(ppm)
    root["VOC"] = mics.getVOC();  //volatile organic compound(ppb)
    root[""] = "";   //Suplhur Dioxide
    root[""] = "";   //Ozone
    root["PM1.0"] = pms.pm01;   //PM1.0(ug/m3)
    root["PM2.5"] = pms.pm25;   //PM2.5(ug/m3)
    root["PM10"] = pms.pm10;   //PM10(ug/m3)
    root["0.3um"] = pms.n0p3;   //particle 0.3um/0.1l
    root["1um"] = pms.n1p0;   //particle 1um/0.1l
    root["2.5um"] = pms.n2p5;   //particle 2.5um/0.1l
    root["5um"] = pms.n5p0;   //particle 5um/0.1l
    root["0um"] = pms.n10p0;   //particle 10um/0.1l
    root["y"] = ""; //sequence number 
    root["z"] = sequenceNo;//modemGSM.getGSMDateTime(); //Unknown parameter
    root["sig"]  =  modemGSM.getSignalQuality(); //rssi
    root["bat"]  =  modemGSM.getBattVoltage();  //battery level(%)
    root["fmv"]  =  FIRMWARE_VER;
    root["loc"]  =  modemGSM.getGsmLocation();
    root["sid"]  = rst_cnt; 
    root["imei"] = imei;  //device id(imei)

    

    //String jsonStr;
    serializeJson(root, Serial);
    Serial.println(" ");
Serial.println("CO: 1 – 1000ppm | NO2: 0.05 – 10ppm | C2H6OH: 10 – 500ppm | H2: 1 – 1000ppm");
Serial.println("NH3: 1 – 500ppm | 100000ppm>CH4 >1000ppm | C3H8 >1000ppm | C4H10 >1000ppm");
Serial.println("PM values can't be zeros");
Serial.println("15<Temp<35 | Pressure ~ 100000Pa" );
Serial.println("400<CO2<1000 | 0<VOC<1000" );

  if(ideamartmqtt.publish(EVENT_TOPIC,imei.c_str())==true){
    sequenceNo++;
  }
  

}


